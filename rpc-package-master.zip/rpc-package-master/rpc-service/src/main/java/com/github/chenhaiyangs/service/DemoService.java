package com.github.chenhaiyangs.service;

import com.github.chenhaiyangs.dto.DemoRequest;
import com.github.chenhaiyangs.dto.DemoResponse;

/**
 * @author chenhaiyang
 */
public interface DemoService {
    /**
     * xx xxx llxxxxxxxxxx
     * @param request xxxxx
     * @return xxxxxxxx
     */
    DemoResponse sayHelloWorld(DemoRequest request);
}
